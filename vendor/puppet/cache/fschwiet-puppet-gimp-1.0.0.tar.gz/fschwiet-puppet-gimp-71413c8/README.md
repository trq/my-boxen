# GIMP Puppet Module for Boxen

## Usage

```puppet
include gimp 
```

## Required Puppet Modules

None.

## Developing

Write code.

Run `script/cibuild`.
